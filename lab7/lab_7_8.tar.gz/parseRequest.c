#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Citeste cererea clientului. Pune numele fisierului intr-un string.
 * Daca sintaxa nu este corecta sau lipsesk retururi la linii
 * se trimite -1. In caz contrar functia transmite 0.
 * requestFromClient este sirul de 1000 octeti care contine cererea provenita de
 * la client. requestSize trebuie sa egala cu 1000 (si nu la lungimea sirului de
 * caractere).
 */

int parseRequest(char *requestFromClient, int requestSize, char *string,
                 int stringSize) {
  /* charPtr[4] este un tabel cu 4 pointere care poiteaza asupra inceputului
   * sirului, cele 2 spatii 	*/
  /* ale cererii (cel de dupa GET si cel de dupa numelefisierului)	*/
  /* Pointerul end se va utiliza pentru a pune un '\0' la sfarsitul returului
   * dublu la linie.		*/

  char *charPtr[4], *end;

  /* Se cauta dublul retur la linie in requestFromClient
   * in functie de sisteme de va utiliza \r sau \n (new line, new feed)
   * prin conventie in http se utilizeaza ambele \r\n dar in practic e vorba de
   * un singur retur la linie. Pentru a simplifica, aici se cauta doar '\n'. Se
   * va plasa un '\0' imediat dupa dublul retur la linie permitand prelucrarea
   * cererii casi uilizarea functiilor din biblioteca string.h.
   */

  /* Citire pana la dublul retur de linie */
  requestFromClient[requestSize - 1] =
      '\0'; // Permite utilizarea strchr() - atentie, nu merge daca requestSize
            // indica lungimea sirului de caractere

  if ((end = strstr(requestFromClient, "\r\n\r\n")) == NULL)
    return (-1);
  *(end + 4) = '\0';

  // Verificarea syntaxei (GET fisier HTTP/1.1)
  charPtr[0] = requestFromClient; // Inceputul cererii (GET in principiu)
  // Se cauta primul spatiu, codul ascii 0x20 (in hexa), este inceputul numelui
  // fisierului
  charPtr[1] = strchr(requestFromClient, ' ');
  if (charPtr[1] == NULL)
    return (-1);
  charPtr[2] = strchr(charPtr[1] + 1, ' ');
  if (charPtr[2] == NULL)
    return (-1);
  charPtr[3] = strchr(charPtr[2] + 1, '\r');
  if (charPtr[3] == NULL)
    return (-1);

  // Se separa sirurile
  *charPtr[1] = '\0';
  *charPtr[2] = '\0';
  *charPtr[3] = '\0';

  if (strcmp(charPtr[0], "GET") != 0)
    return (-1);
  if (strcmp(charPtr[2] + 1, "HTTP/1.1") != 0)
    return (-1);
  strncpy(string, charPtr[1] + 2,
          stringSize); // Se decaleasa sirul cu 2 octeti: primul octet este
                       // '\0', al doilea decalaj permite sa retragem "/"

  // Daca stringSize nu este suficient de mare, sirul nu contine '\0'. Pentru a
  // verifica et suficient sa testam string[stringSize-1] care
  //  trebuie sa fie = '\0' deoarece  strncpy unple sirul cu '\0' cand exista
  //  loc.
  if (string[stringSize - 1] != '\0') {
    fprintf(stderr,
            "Erreur parseRequest(): lungimea sirului string nu este suficienta "
            "(stringSize=%d)\n",
            stringSize);
    exit(3);
  }

  // DEBUG
  if (*(charPtr[1] + 2) == '\0')
    fprintf(stderr, "DEBUG-SERVEUR: nomele fisieruui est vid -\nDEBUG-SERVEUR: "
                    "- se asociaza fisierul implicit index.html\n");
  else
    fprintf(stderr, "DEBUG-SERVEUR: numele fisierului cerut este %s\n", string);

  if (*(charPtr[1] + 2) == '\0')
    strcpy(string, "index.html");

  return (0);
}
